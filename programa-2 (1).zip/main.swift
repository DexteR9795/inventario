var aux: String = ""
var opcionIngresada: String = aux // Guardar los datos que ingresa el usuario

var saldoTotal: Double = 0.0 // Mostrar el saldo total
var primeraVez: Bool = true

func deposito() {
print("Ingresa la cantidad a depositar: ")
aux = readLine( )!
opcionIngresada = aux
//Crear una variable para el deposito Double
let cantidadDepositada = Double(opcionIngresada) ?? 0.0
  print("Abono con exito por  $ \(cantidadDepositada)")
  saldoTotal = saldoTotal + cantidadDepositada
  print("\n")

  // Se hace la suma al saldo total
  saldoTotal = saldoTotal + cantidadDepositada
  print("\n")

  }

  func retiro( ) {
  if primeraVez || saldoTotal == 0.0 {
  print("No cuentas con saldo, favor de realizaer un deposito")
  primeraVez = false
    } else {
    print("\n")
    print("Ingresa la cantidad a retirar: ")
    

    aux = readLine( )!
    opcionIngresada = aux
    
    // Crear una var double para poder restarla del saldo total
    let cantidadRetirar = Double(opcionIngresada)!// extraccion forzada (force unwrapping)
    
    if cantidadRetirar <= saldoTotal {
    print("Retiro exitoso por $ \(cantidadRetirar)")
    print ("\n")
      // saldo actual
      } else {
      print("\n")
      print("No cuentas con saldo suficiente,favor de realizar un deposito")

      }
    }
    }
  while opcionIngresada != "4" {
print(" ***** BANCO COPPEL ******* ")
print("\n")
print("1 .- Deposito")
print("2 .- Retiro")
print("3 .- Consultar saldo" )
print("4 .- Salir")

  aux = readLine( )!
  opcionIngresada = aux

 
    switch opcionIngresada {
    case "1":
    deposito( )
    print("\n")
    print("¿Deseas realizar otro deposito? (S/N) : ")

    aux = readLine( )!
    opcionIngresada = aux

      // hacer otro deposito
      if opcionIngresada == "S" || opcionIngresada == "s" {
      deposito()
      }
      if opcionIngresada == "N" || opcionIngresada == "n" || opcionIngresada == "no"
      || opcionIngresada  == "NO"  {
      deposito( )  
        print("¿Desea continuar con otra operacion? (N/S) ")
        aux = readLine( )!
        opcionIngresada = aux

        if (opcionIngresada == "N") || (opcionIngresada == "NO") || (opcionIngresada == "no") ||
        (opcionIngresada == "n") {
        print("Cerrando sesion, vuelva pronto!")
        opcionIngresada = "4"
      }
      }
      case "2":
      retiro()
      print("\n")
      print("desea realizar otro retiro? (s/n)")
      aux = readLine()!
      opcionIngresada = aux

      switch opcionIngresada {
      case "S", "s", "si", "SI", "Si":
      retiro()

      case "N", "n", "no", "NO", "No":
        print("\n")
      print("¿Desea continuar con otra operacion? (N/S)")

        aux = readLine( )!
        opcionIngresada = aux

        if opcionIngresada == "N" || opcionIngresada == "NO" ||
        opcionIngresada == "no" {
        print("Cerrando sesion, vuelva pronto!")
        opcionIngresada = "4" // salir

        }

        
        default:
        print("opcion no valida")

      }

      case "3":
      print("\n")
      print("Tu saldo actual es de $\(saldoTotal) pesos")

      case "4":
      print("cerrando sesion, vuelva pronto!")

    
  default:
  print("\n")
  print("Opcion no valida")

  }

  
}